from .base import face2folder2mango

def main():
    path=raw_input('path of folder that contains pictures: ')
    face2folder2mango(path)