rekog2json2mongo
-------------------

call AWS rekognition api, pushing local images, saving api results to json as well as mongodb
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~